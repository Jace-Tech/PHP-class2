<?php  

// Products array

$products = [
    [
        "id" => "pdt-000001",
        "title" => "iPhone 13 pro max",
        "description" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iure ea assumenda similique perferendis modi? Quisquam animi dolor quos debitis necessitatibus.",
        "price" => number_format(1250000),
        "image" => "iphone.png"
    ],
    [
        "id" => "pdt-000002",
        "title" => "Macbook Pro '13",
        "description" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iure ea assumenda similique perferendis modi? Quisquam animi dolor quos debitis necessitatibus.",
        "price" => number_format(320000),
        "image" => "macbook.png"
    ],
    [
        "id" => "pdt-000002",
        "title" => "HP Omen",
        "description" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iure ea assumenda similique perferendis modi? Quisquam animi dolor quos debitis necessitatibus.",
        "price" => number_format(550000),
        "image" => "omen.png"
    ],
];